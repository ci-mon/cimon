import jetbrains.buildServer.configs.kotlin.*
import jetbrains.buildServer.configs.kotlin.buildSteps.script
import jetbrains.buildServer.configs.kotlin.vcs.GitVcsRoot

/*
The settings script is an entry point for defining a TeamCity
project hierarchy. The script should contain a single call to the
project() function with a Project instance or an init function as
an argument.

VcsRoots, BuildTypes, Templates, and subprojects can be
registered inside the project using the vcsRoot(), buildType(),
template(), and subProject() methods respectively.

To debug settings scripts in command-line, run the

    mvnDebug org.jetbrains.teamcity:teamcity-configs-maven-plugin:generate

command and attach your debugger to the port 8000.

To debug in IntelliJ Idea, open the 'Maven Projects' tool window (View
-> Tool Windows -> Maven Projects), find the generate task node
(Plugins -> teamcity-configs -> teamcity-configs:generate), the
'Debug' option is available in the context menu for the task.
*/

version = "2023.11"

project {

    vcsRoot(HttpGogs3001rootTest1git)

    buildType(BuildConf1)
}

object BuildConf1 : BuildType({
    name = "Build test1"

    vcs {
        root(HttpGogs3001rootTest1git)
    }

    steps {
        script {
            id = "simpleRunner"
            scriptContent = """/bin/bash ./run.sh "%build.counter%""""
        }
    }
})

object HttpGogs3001rootTest1git : GitVcsRoot({
    name = "http://gogs:3001/root/test1.git"
    url = "http://gogs:3001/root/test1.git"
    branch = "refs/heads/master"
    branchSpec = "*"
    authMethod = password {
        userName = "root"
        password = "zxx741d04a9fba8ad6f"
    }
})
